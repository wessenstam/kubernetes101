#!/bin/sh
/usr/sbin/nginx -c /etc/nginx/nginx.conf
