#!/bin/sh
/usr/sbin/php-fpm7
